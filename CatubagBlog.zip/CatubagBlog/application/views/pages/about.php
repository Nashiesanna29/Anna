<h2><?= $title ?></h2>

</p><h2 style="color:yellow;" align="center"> HELLO & WELCOME TO MY FIRST BLOG POST </h2></p>
</p><h2 style="color:green;" align="center"> Pizza </h2></p>

<p style="text-align: justify" > I am very foodie. I love to eat and cook. The food gives us energy. Without food, there is no life. Among the number of food Pizza is my favorite food because it tastes and smells fabulous. The pizza itself looks so yummy, crispy and so cheesy. There is no better feeling in the world than a warm pizza box on your lap. My love for Pizza is very high. 


I am always hungry for pizza, be it any time of the day. Cheese is the secret ingredient of any food it makes any food taste yummy. Nearly any ingredient can be put on pizza. Those diced vegetables, jalapenos, tomato sauce, cheese and mushrooms makes me eat more and more like a unique work of art. Every pie is a different shape and size. There are thin crust pies, deep dish pies, and everything in between. There are pies with different cheeses and tomato sauce, or even pies with a completely different base altogether. 


On every occasion, I celebrate it with pizza style. There are times when I get scolded for having pizza all the time because anything in excess causes harms to our health but a pizza lover will always be a pizza lover. There is something between me and pizza the bond which cannot be broken. No matter how much I have eaten, I never fail to make myself feel hungry when I have my favorite pizzas in front of me. Flavors are felt exploding in my mouth when I take the 1st bite of my pizza.</p>