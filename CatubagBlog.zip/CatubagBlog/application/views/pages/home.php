<h2><?= $title ?></h2>

<p style="color:black" style="text-align: justify"> "I am a simple person who hides a thousand feelings behind the happiest smile." </p>


<p><h1  style="color:red;"> Hi, I'm Anna Jane Catubag. </h1>

<h2  style="color: yellow"> Let me work with you to achieve your biggest goals and dreams. </h2></p>

<p><h3 style="text-align: center">  NEVER GIVE UP </p></h3>

<p><h4 style="text-align: center;">  ON YOUR  </p></h4>

<p><h5 style="text-align: center;">  DREAMS </p></h5>

<p><h6 style="text-align: center;">  NO MATTER HOW HARD  </p></h6>

<p><h4 style="text-align: center;">  IT GETS </p></h4>